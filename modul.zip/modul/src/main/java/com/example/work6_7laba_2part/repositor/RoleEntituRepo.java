package com.example.work6_7laba_2part.repositor;

import com.example.work6_7laba_2part.entity.RoleEntity;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RoleEntituRepo extends JpaRepository<RoleEntity, Long> {
}
