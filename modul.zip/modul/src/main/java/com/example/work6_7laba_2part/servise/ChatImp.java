package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.repositor.ChatsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//чат с сообщениями
@Service("chatImp")
public class ChatImp implements ChatsRepo {
    private final ChatsRepo chatsRepo;

    @Autowired
    public ChatImp(ChatsRepo chatsRepo) {
        this.chatsRepo = chatsRepo;

    }
}
