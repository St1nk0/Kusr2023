package com.example.work6_7laba_2part.controllers;
import com.example.work6_7laba_2part.entity.ClientloginEntity;
import com.example.work6_7laba_2part.servise.SecurityClientLoginImp;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/auth")
public class Controller_pos
{
    private final SecurityClientLoginImp securityClientLoginImp;
@Autowired
    public Controller_pos(SecurityClientLoginImp securityClientLoginImp)
    {
        this.securityClientLoginImp = securityClientLoginImp;
    }

    @GetMapping("/login")
    public String getLoginPage()
    {
        return "login2";
    }

    @GetMapping("/succses")
    public String getSuccsesPage(Model model)
    {
        model.addAttribute("allUsers", securityClientLoginImp.allUsers());
        return "succses2";
    }

    @PostMapping("/succses")
    public String setSuccsesPage(Model model)
    {
        model.addAttribute("allUsers", securityClientLoginImp.allUsers());
        return "succses2";
    }
    @GetMapping("/delete/{idclient}")
    public String deleteUser(@PathVariable("idclient") Long idclient, Model model)
    {
        ClientloginEntity clientloginEntity = securityClientLoginImp.findById(idclient);
        securityClientLoginImp.deleteUser(clientloginEntity);
        return "redirect:/auth/succses";
    }

    @GetMapping("/edit/{idclient}")
    public String getUserId(@PathVariable("idclient") Long idclient, Model model)
    {
        model.addAttribute("clientloginEntity", securityClientLoginImp.findById(idclient));
        return "update-user";
    }

    @PostMapping("/update/{idclient}")
    public  String updateUser(@PathVariable("idclient") Long idclient, @Valid ClientloginEntity clientlogin,
                              BindingResult result, Model model)
    {
        if (result.hasErrors())
        {
            clientlogin.setIdclient(idclient);
            return "update-user";
        }
        securityClientLoginImp.updateUser(clientlogin);
        return "redirect:/auth/succses";
    }
}
