package com.example.work6_7laba_2part.repositor;

import com.example.work6_7laba_2part.entity.PostsEntity;
import org.springframework.data.repository.CrudRepository;

public interface PostsEntityRepo extends CrudRepository<PostsEntity, Long> {
    @Override
    Iterable<PostsEntity> findAll();

}
