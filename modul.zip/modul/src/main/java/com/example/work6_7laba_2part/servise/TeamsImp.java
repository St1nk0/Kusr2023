package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.repositor.TeamsEntityRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("teamsImp")
public class TeamsImp {
    private final TeamsEntityRepo teamsEntityRepo;

    @Autowired
    public TeamsImp(TeamsEntityRepo teamsEntityRepo) {
        this.teamsEntityRepo = teamsEntityRepo;
    }

    //public TeamsEntity findById(Long idteam){}
}
