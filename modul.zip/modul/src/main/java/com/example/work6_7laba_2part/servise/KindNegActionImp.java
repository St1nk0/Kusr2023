package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.repositor.AudienceRepo;
import com.example.work6_7laba_2part.repositor.KindNegActionsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//виды негатинвых действий
@Service("kindNegActionImp")
public class KindNegActionImp implements KindNegActionsRepo {
    private final KindNegActionsRepo kindNegActionsRepo;

    @Autowired
    public KindNegActionImp(KindNegActionsRepo kindNegActionsRepo) {
        this.kindNegActionsRepo = kindNegActionsRepo;

    }
}
