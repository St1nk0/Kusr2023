package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.repositor.AudienceRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("audienceImp")
public class AudienceImp implements AudienceRepo {
    private final AudienceRepo audienceRepo;

    @Autowired
    public AudienceImp(AudienceRepo audienceRepo) {
        this.audienceRepo = audienceRepo;

    }
}
