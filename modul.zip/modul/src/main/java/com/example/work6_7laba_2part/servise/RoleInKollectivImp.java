package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.repositor.CustomRoleRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("roleInKollectivImp")
public class RoleInKollectivImp implements CustomRoleRepo {
    private final CustomRoleRepo customRoleRepo;

    @Autowired
    public RoleInKollectivImp(CustomRoleRepo customRoleRepo) {
        this.customRoleRepo = customRoleRepo;

    }
}
