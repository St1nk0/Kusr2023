package com.example.work6_7laba_2part.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "teams", schema = "securityspring1")
public class TeamsEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "idteams")
    private Long idteams;

    @Column(name = "name_team")
    private String nameTeam;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TeamsEntity that = (TeamsEntity) o;
        return idteams == that.idteams && Objects.equals(nameTeam, that.nameTeam);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idteams, nameTeam);
    }
}
