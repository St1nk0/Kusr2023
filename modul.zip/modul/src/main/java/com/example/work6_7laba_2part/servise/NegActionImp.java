package com.example.work6_7laba_2part.servise;

//негативные действия и к кому они относятся

import com.example.work6_7laba_2part.repositor.AudienceRepo;
import com.example.work6_7laba_2part.repositor.NegActionsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("audienceImp")
public class NegActionImp implements NegActionsRepo {
    private final NegActionsRepo negActionsRepo;

    @Autowired
    public NegActionImp(NegActionsRepo negActionsRepo) {
        this.negActionsRepo = negActionsRepo;

    }
}
