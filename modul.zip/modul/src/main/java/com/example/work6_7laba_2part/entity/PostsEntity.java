package com.example.work6_7laba_2part.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Objects;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "posts", schema = "securityspring1")
public class PostsEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "idpost")
    private Long idpost;
    @Basic
    @Column(name = "name_post")
    private String namePost;
    @Basic
    @Column(name = "link_video")
    private String linkVideo;
    @Basic
    @Column(name = "del")
    private Boolean del;


    public PostsEntity(String namePost, String linkVideo) {
        this.namePost = namePost;
        this.linkVideo = linkVideo;
        this.del = false;
    }

    public void setDel(Boolean del)
    {
        this.del = del;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PostsEntity that = (PostsEntity) o;
        return idpost == that.idpost && Objects.equals(namePost, that.namePost);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idpost, namePost);
    }



}
