package com.example.work6_7laba_2part.controllers;

import com.example.work6_7laba_2part.entity.ClientloginEntity;
import com.example.work6_7laba_2part.entity.PostsEntity;
import com.example.work6_7laba_2part.repositor.PostsEntityRepo;
import com.example.work6_7laba_2part.servise.PostsImp;
import com.example.work6_7laba_2part.servise.SecurityClientLoginImp;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Optional;

@Controller
public class ControllerReg
{
    @Autowired
    private SecurityClientLoginImp securityClientLoginImp;
    @Autowired
    private PostsImp postsImp;
    @Autowired
    private PostsEntityRepo postsEntityRepo;

    @GetMapping("/auth/register")
    public String getRegistrPage(Model model)
    {
        model.addAttribute("userForm", new ClientloginEntity());
        return "register";
    }
    @GetMapping("/about-us")
    public String getAboutUs(Model model)
    {
        model.addAttribute("title", "О нас");
        return "about-us";
    }

    @GetMapping("/main")
    public String getMainPage(Model model)
    {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        ClientloginEntity user = (ClientloginEntity) authentication.getPrincipal();
        if (user != null)
        {
            model.addAttribute("idclient", user.getIdclient());
        }
        else
        {
            model.addAttribute("idclient", 0L);
        }
        //вытягивание всех постов
        //Iterable<PostsEntity> posts= postsEntityRepo.findAll();
        model.addAttribute("posts",postsImp.allPosts());
        return "main";
    }

    @GetMapping("/main/add-video")
    public String getAdd(Model model){
        model.addAttribute("postEntity",new PostsEntity());
        model.addAttribute("addV", "Добавить видео");
        return "add-video";
    }
    @PostMapping("/main/add-video")
    public String postAdd(@Valid PostsEntity postsEntity ){
        postsImp.savePost(postsEntity);
        //model.addAttribute("addV", "Добавить видео");
        return "redirect:/main";
    }

    @GetMapping("/main/edit-post/{idpost}")
    public String getEditPost(@PathVariable(value = "idpost") Long idpost,Model model){
        model.addAttribute("addU", "Upddate video");
        if(!postsEntityRepo.existsById(idpost)){
            return "redirect:/main";
        }
        PostsEntity postsEntity = postsEntityRepo.findById(idpost).orElse(new PostsEntity());
        //postsEntityOptional.ifPresent(res::add);
        model.addAttribute("postsEntity",postsEntity);
      /*  model.addAttribute("post",new PostsEntity());*/
        return "edit-post";
    }

    @PostMapping("/main/edit-post/{idpost}")
    public String postEditPost(@PathVariable("idpost") Long idpost, @RequestParam String namePost, @RequestParam String linkVideo) {
            PostsEntity postsEntity1 = postsEntityRepo.findById(idpost).orElseThrow();
            postsEntity1.setNamePost(namePost);
            postsEntity1.setLinkVideo(linkVideo);
            postsImp.savePost(postsEntity1);
           /* postsImp.savePost(postsEntity);*/
            return "redirect:/main";
    }

    @PostMapping("/main/remove-post/{idpost}")
    public String postRemovepost(@PathVariable("idpost") Long idpost, Model model) {
        PostsEntity postsEntity1 = postsEntityRepo.findById(idpost).orElseThrow();
        postsEntityRepo.delete(postsEntity1);
        return "redirect:/main";
    }

    @GetMapping("/profile/{idclient}")
    public String getProfilePage(@PathVariable("idclient") Long idclient, Model model)
    {
        if (idclient == 0)
            return "redirect:/auth/login";
        model.addAttribute("clientloginEntity", securityClientLoginImp.findById(idclient));
        return "profile";
    }

    @PostMapping("/profile/{idclient}")
    public String editProfilePage(@PathVariable("idclient") Long idclient, Model model)
    {
        if (idclient == 0)
            return "redirect:/auth/login";
        model.addAttribute("clientloginEntity", securityClientLoginImp.findById(idclient));
        model.addAttribute("idclient", idclient);
        return "redirect:edit-profile/{idclient}";
    }

    @GetMapping("/profile/edit-profile/{idclient}")
    public String getEditPage(Model model, @PathVariable("idclient") Long idclient)
    {
        model.addAttribute("clientloginEntity", securityClientLoginImp.findById(idclient));
        model.addAttribute("idclient", idclient);
        if (idclient == 0)
            return "redirect:/auth/login";
        return "edit-profile";
    }

    @PostMapping("/profile/edit-profile/{idclient}")
    public String saveChangesProfile(@ModelAttribute("userForm") @Valid ClientloginEntity userForm, Model model, @PathVariable("idclient") Long idclient)
    {
        if (idclient == 0)
            return "redirect:/auth/login";
        assert userForm != null;
        ClientloginEntity oldUser = securityClientLoginImp.findById(idclient);
        userForm.setLogin(oldUser.getLogin());
        userForm.setPassword(oldUser.getPassword());
        userForm.setIdclient(idclient);
        securityClientLoginImp.updateProfile(userForm);
        model.addAttribute("idclient", idclient);
        model.addAttribute("clientloginEntity", userForm);
        return "profile";
    }

    @GetMapping("../img/{id}")
    private String getImageByID(@PathVariable String id)
    {
        return "src/main/resources/static/img" + id;
    }

    @PostMapping("/auth/register")
    public String save (@ModelAttribute("userForm") @Valid ClientloginEntity userForm, BindingResult bindingResult, Model model){
        if(bindingResult.hasErrors())
        {
            return "register";
        }
        if (!securityClientLoginImp.saveUser(userForm))
        {
            model.addAttribute("usernameError", "Пользователь с таким именем уже существует");
            return "register";
        }
    return "redirect:/auth/login";
    }
}
