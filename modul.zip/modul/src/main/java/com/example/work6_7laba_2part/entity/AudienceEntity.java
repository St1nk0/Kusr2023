package com.example.work6_7laba_2part.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "audience")
public class AudienceEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_audience", nullable = false)
    private Integer id;

    @Column(name = "ID_user_audience")
    private int idUser;

    @Column(name = "Token")
    private String token;

    @Column(name = "ID_watched_discussion")
    private int idDiscussion;

}