package com.example.work6_7laba_2part.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.attoparser.dom.Text;

import java.sql.Timestamp;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "ban")
public class BanEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_ban", nullable = false)
    private Integer id;

    @Column(name = "ID_user")
    private int idUser;

    @Column(name = "Reason")
    private Text reason;

    @Column(name = "Date_and_time")
    private Date date;

    @Column(name = "Timestamp_ban")
    private Timestamp accurateDate;

    @Column(name = "Screenshots")
    private Text proofsPaths;

}