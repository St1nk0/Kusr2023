package com.example.work6_7laba_2part.repositor;
import com.example.work6_7laba_2part.entity.ClientloginEntity;
import org.attoparser.dom.Text;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Optional;

public interface ClientLoginRepo extends JpaRepository<ClientloginEntity, Long> {
    Optional<ClientloginEntity> findByLogin (String login);

    @Transactional
    @Modifying
    @Query("update ClientloginEntity w set w.deleted = true where w.idclient = ?1")
    int updateDeletedById(Long idclient);

    @Transactional
    @Modifying
    @Query("update ClientloginEntity w set  w.password = ?1, w.lastname = ?2, w.login = ?3 where w.idclient =?4")
    int setUpdatePasswordLastnameLogin(String password, String lastname, String login, Long idclient);

    @Transactional
    @Modifying
    @Query("""
            update ClientloginEntity c set c.name = ?1, c.lastname = ?2, c.surname = ?3, c.sex = ?4, c.country = ?5, c.city = ?6, c.birthday = ?7, c.info = ?8, c.email = ?9, c.nickname = ?10, c.photo = ?11
            where c.idclient = ?12""")
    int updateProfile(String name, String lastname, String surname, int sex, String country, String city, Date birthday, Text info, String email, String nickname, String photo, Long idclient);

}