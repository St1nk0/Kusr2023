package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.repositor.CustomRoleSettingsRepo;
import com.example.work6_7laba_2part.repositor.RoleSettingVariablesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("settingRoleCustomImp")
public class SettingRoleCustomImp implements CustomRoleSettingsRepo, RoleSettingVariablesRepo {
    private final CustomRoleSettingsRepo customRoleSettingsRepo;
    private final RoleSettingVariablesRepo roleSettingVariablesRepo;

    @Autowired
    public SettingRoleCustomImp(CustomRoleSettingsRepo customRoleSettingsRepo, RoleSettingVariablesRepo roleSettingVariablesRepo) {
        this.customRoleSettingsRepo = customRoleSettingsRepo;
        this.roleSettingVariablesRepo = roleSettingVariablesRepo;

    }
}
