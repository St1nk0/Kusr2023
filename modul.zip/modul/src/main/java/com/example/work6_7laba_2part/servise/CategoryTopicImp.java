package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.repositor.CategoryRepo;
import com.example.work6_7laba_2part.repositor.TopicRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("categoryTopicImp")
public class CategoryTopicImp implements CategoryRepo, TopicRepo {
    private final CategoryRepo categoryRepo;
    private final TopicRepo topicRepo;

    @Autowired
    public CategoryTopicImp(CategoryRepo categoryRepo, TopicRepo topicRepo) {
        this.categoryRepo = categoryRepo;
        this.topicRepo = topicRepo;
    }
}
