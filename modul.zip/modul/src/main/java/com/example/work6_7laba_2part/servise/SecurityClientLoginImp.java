package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.entity.ClientloginEntity;
import com.example.work6_7laba_2part.entity.RoleEntity;
import com.example.work6_7laba_2part.repositor.ClientLoginRepo;
import com.example.work6_7laba_2part.repositor.RoleEntituRepo;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;
import java.util.Date;
import java.text.DateFormat;


@Service("securityClientLoginImpl")
public class SecurityClientLoginImp implements UserDetailsService
{
    private final ClientLoginRepo clientLoginRepo;
    private final RoleEntituRepo roleEntituRepo;

    private PasswordEncoder passwordEncoder;

    @Autowired
    public SecurityClientLoginImp(ClientLoginRepo clientLoginRepo, RoleEntituRepo roleEntituRepo) {
        this.clientLoginRepo = clientLoginRepo;
        this.roleEntituRepo = roleEntituRepo;
    }

//если не найден выбросит ошибку
    @Override
    public ClientloginEntity loadUserByUsername(String login) throws UsernameNotFoundException
    {
        return clientLoginRepo.findByLogin(login).orElseThrow(() ->
               new UsernameNotFoundException("User doesn't exists"));
    }

    public ClientloginEntity findById(Long idclient){
        Optional<ClientloginEntity> userFromDb = clientLoginRepo.findById(idclient);
        return userFromDb.orElse(new ClientloginEntity());
    }
    public List<ClientloginEntity> allUsers() {
        return clientLoginRepo.findAll();
    }

    public boolean saveUser(ClientloginEntity clientloginEntity) {
        Optional<ClientloginEntity> userFromDB = clientLoginRepo.findByLogin(clientloginEntity.getLogin());

        if (userFromDB.isPresent()) {
            return false;
        }
        passwordEncoder = new BCryptPasswordEncoder(12);
        clientloginEntity.setPassword(passwordEncoder.encode(clientloginEntity.getPassword()));
        clientloginEntity.setRoleByRole(new RoleEntity(4L, "ROLE_USER"));
        clientloginEntity.setRoleC(4);
        clientloginEntity.setDeleted(false);
        clientLoginRepo.save(clientloginEntity);
        //setRole(clientloginEntity );
        return true;
    }

    public void deleteUser(@NotNull ClientloginEntity clientloginEntity)
    {
            clientLoginRepo.updateDeletedById(clientloginEntity.getIdclient());
    }

    public void updateUser(ClientloginEntity clientloginEntity)
    {
        clientLoginRepo.setUpdatePasswordLastnameLogin(
                clientloginEntity.getPassword(),
                clientloginEntity.getLastname(),
                clientloginEntity.getLogin(),
                clientloginEntity.getIdclient());
    }

    public void updateProfile(ClientloginEntity clientloginEntity)
    {
        clientLoginRepo.updateProfile(
                clientloginEntity.getName(),
                clientloginEntity.getLastname(),
                clientloginEntity.getSurname(),
                clientloginEntity.getSex(),
                clientloginEntity.getCountry(),
                clientloginEntity.getCity(),
                clientloginEntity.getBirthday(),
                clientloginEntity.getInfo(),
                clientloginEntity.getEmail(),
                clientloginEntity.getNickname(),
                clientloginEntity.getPhoto(),
                clientloginEntity.getIdclient()
        );
    }

}
