package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.repositor.BanRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("banImp")
public class BanImp implements BanRepo{
    private final BanRepo banRepo;
    @Autowired
    public BanImp(BanRepo banRepo) {
        this.banRepo = banRepo;

    }
}
