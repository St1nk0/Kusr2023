package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.repositor.LikesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("LikeImp")
public class LikeImp implements LikesRepo {
    private final LikesRepo likesRepo;
    @Autowired
    public LikeImp(LikesRepo likesRepo) {
        this.likesRepo = likesRepo;

    }
}
