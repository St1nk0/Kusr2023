package com.example.work6_7laba_2part.entity;

public class CategoryEntity {
}
