package com.example.work6_7laba_2part.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "negativeactionkinds")
public class KindNegActionEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_kind", nullable = false)
    private Integer id;

    @Column(name = "Name")
    private String name;

    @Column(name = "Badrate")
    private int badRate;

}