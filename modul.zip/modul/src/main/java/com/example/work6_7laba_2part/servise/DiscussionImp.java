package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.repositor.AudienceRepo;
import com.example.work6_7laba_2part.repositor.DisscussionsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("discussionImp")
public class DiscussionImp implements DisscussionsRepo {
    private final DisscussionsRepo disscussionsRepo;

    @Autowired
    public DiscussionImp(DisscussionsRepo disscussionsRepo) {
        this.disscussionsRepo = disscussionsRepo;

    }
}