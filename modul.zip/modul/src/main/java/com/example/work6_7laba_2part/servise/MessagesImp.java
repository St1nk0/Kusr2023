package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.repositor.MessagesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//само сообщение
@Service("messagesImp")
public class MessagesImp implements MessagesRepo {
    private final MessagesRepo messagesRepo;

    @Autowired
    public MessagesImp(MessagesRepo messagesRepo) {
        this.messagesRepo = messagesRepo;

    }
}
